# Cursor Command Queue — Titan‑Mode v3

**-2 Longbrain Retrieval (always)**
Run: `.\ops\hot-cache.ps1 -q "<task in 8–12 words>"`  
Then: `.\ops\context-mesh.ps1 -windowTokens 64000`  
Load `context/_mesh/INDEX.md`. Work window-by-window.

**-1 Delta Mode (iterative)**
If continuing an unfinished feature, run: `.\ops\delta-stream.ps1` and prefer `context/_delta/DIFF.patch`.

**0 Load Context**
Open `context/_latest/context_index.md`. Respect `write_targets.txt`; treat `risk_zones.txt` as read‑only unless approved.

**1 Plan**
Read white papers. Output `PLAN.md` with exact file targets and tests to add/update.

**2 Lint/Tests First**
If `placeholders.json` has `Severity == BLOCK` → stop and open task `remove-blockers`. Run lints/tests; fix minimal surface first.

**3 Implement**
Create a feature branch: `.\ops\patch-forge.ps1 -featureName "feat-<slug>"`. Propose diffs in `PATCH_NOTES/<id>.md`. Only edit paths in `write_targets.txt`.

**4 Owner Pings**
If `ownership.json` lists Owner != "AI" for a changed path, append a fenced diff to `PLAN.md → Owner Pings` with rationale.

**5 Summarize**
Regenerate context pack. Create `CHANGE_SUMMARY.md` with touched files, tests added, and any TODOs created.
