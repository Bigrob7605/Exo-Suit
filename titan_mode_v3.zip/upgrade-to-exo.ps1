$ErrorActionPreference = 'Stop'; Set-StrictMode -Latest

$need = @('python','git','pwsh')
foreach ($n in $need) {
  if (-not (Get-Command $n -EA SilentlyContinue)) { throw "$n missing on PATH" }
}

# Dirs
'mermaid','rag','restore','context\_latest','longbrain' | % { New-Item -ItemType Directory -Force $_ | Out-Null }

# Python deps (GPU first, fallback CPU)
python -m pip install --upgrade pip wheel setuptools
$gpu = (Get-Command nvidia-smi -EA SilentlyContinue) -ne $null
pip install torch --index-url https://download.pytorch.org/whl/cu121 2>$null
if ($gpu) {
  try { pip install faiss-gpu -q } catch { pip install faiss-cpu -q }
} else { pip install faiss-cpu -q }
pip install sentence-transformers psutil numpy mermaid-py rank-bm25 tqdm

# ripgrep (warn if missing)
if (-not (Get-Command rg -EA SilentlyContinue)) {
  Write-Warning "ripgrep (rg) not found. Install for faster indexing: https://github.com/BurntSushi/ripgrep/releases"
}

# .env
@"
EMBEDDING_MODEL=all-MiniLM-L6-v2
FAISS_INDEX_PATH=rag/index.faiss
RAG_META_PATH=rag/meta.jsonl
CACHE_DRIVE=C:
CHUNK_TOKENS=800
CHUNK_OVERLAP=120
TOPK=60
"@ | Out-File '.env' -Encoding utf8

Write-Host "✅ Exo‑Suit v2 bootstrap (Titan v3 deps) complete. Run .\go-big.ps1" -ForegroundColor Green
