param([string]$featureName = "ai-$([DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss'))")

git rev-parse --is-inside-work-tree 2>$null | Out-Null
git switch -c $featureName
git add -A
git commit -m "AI: $featureName" --allow-empty
git diff main...HEAD | Out-File "restore/AI_PATCH.diff" -Encoding utf8
