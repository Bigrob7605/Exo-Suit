$ErrorActionPreference='Stop'
Set-StrictMode -Latest
New-Item -ItemType Directory -Force -Path 'restore' | Out-Null

function Glob($pattern) {
  $pattern = $pattern -replace '\\','/'
  $pattern = $pattern -replace '\*\*','(.+?)' -replace '\*','([^/]+?)'
  $rx = '^' + [regex]::Escape($pattern).Replace('\(\.\+\?\)','(.+?)').Replace('\(\[\^/\]\+\?\)','([^/]+?)') + '$'
  $rx = $rx.Replace('\/','[\\/]')
  $files = Get-ChildItem -Recurse -File | % FullName
  return $files | Where-Object { $_ -replace '\\','/' -match $rx }
}

if (-not (Get-Module -ListAvailable -Name powershell-yaml)) {
  Write-Warning "powershell-yaml module not found. Run: Install-Module powershell-yaml -Scope CurrentUser -Force"
  exit 0
}

$map = (Get-Content 'ops/specmap.yaml' -Raw)
$yaml = ConvertFrom-Yaml $map
if (-not $yaml) { throw "Failed to parse specmap.yaml" }

$gaps = @()
foreach ($entry in $yaml.spec) {
  $codeHits = @(); foreach ($c in $entry.code) { $codeHits += Glob $c }
  $testHits = @(); foreach ($t in $entry.tests) { $testHits += Glob $t }
  if ($codeHits.Count -eq 0) { $gaps += [pscustomobject]@{ id=$entry.id; type='CODE_MISSING'; doc=$entry.doc; pattern=($entry.code -join ', ') } }
  if ($testHits.Count -eq 0) { $gaps += [pscustomobject]@{ id=$entry.id; type='TEST_MISSING'; doc=$entry.doc; pattern=($entry.tests -join ', ') } }
}

$path = 'restore/SPECMAP_REPORT.json'
$gaps | ConvertTo-Json -Depth 4 | Out-File $path -Encoding utf8

if ($gaps.Count -gt 0) { Write-Warning "Spec gaps found. See $path" } else { Write-Host "Spec map clean." }
