import re, json, argparse, pathlib

p=argparse.ArgumentParser()
p.add_argument("--infile", required=True)
p.add_argument("--outfile", required=True)
args=p.parse_args()

src = open(args.infile, encoding='utf-8', errors='ignore').read()
lines = src.splitlines(True)

out, mapidx = [], []
for i,ln in enumerate(lines, start=1):
    stripped = ln.rstrip()
    if not stripped.strip():
        continue
    compact = re.sub(r' {3,}', '  ', stripped)
    out.append(compact+"\n")
    mapidx.append({"dst": len(out), "src": i})

pathlib.Path(args.outfile).write_text(''.join(out), encoding='utf-8')
pathlib.Path(args.outfile + ".map.json").write_text(json.dumps(mapidx), encoding='utf-8')
print(json.dumps({"in_lines":len(lines),"out_lines":len(out)}))
