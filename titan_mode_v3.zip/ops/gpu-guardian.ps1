param([int]$minFreeMB=1024)

$ErrorActionPreference='Stop'
if (-not (Get-Command nvidia-smi -EA SilentlyContinue)) { Write-Host "No NVIDIA detected."; exit 0 }
$sm = (nvidia-smi --query-gpu=memory.total,memory.used,temperature.gpu --format=csv,noheader).Split(",")
$total=[int]$sm[0].Trim().Split()[0]
$used=[int]$sm[1].Trim().Split()[0]
$temp=[int]$sm[2].Trim()
$free=$total-$used
$advice = if ($free -lt $minFreeMB -or $temp -gt 84) { "LOW" } else { "OK" }
@"
GPU Guardian:
  totalMB: $total
  usedMB : $used
  tempC  : $temp
  freeMB : $free
  advice : $advice
"@ | Out-File 'restore/GPU_STATUS.txt' -Encoding utf8
Write-Host "GPU status: $advice"
