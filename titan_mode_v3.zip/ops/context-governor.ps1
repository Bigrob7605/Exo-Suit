param([int]$maxTokens = 128000)

if (!(Test-Path 'rag/context_topk.jsonl') -and !(Test-Path 'context/_latest/TRIMMED.json')) { Write-Warning "No RAG context found."; exit 0 }
$budget = $maxTokens
$sel = @()

function AddLine($o){
  $tok = [math]::Ceiling(($o.text.Length)/4.0)
  if ($tok -le $budget) { $script:sel += $o; $script:budget -= $tok; return $true } else { return $false }
}

if (Test-Path 'rag/context_topk.jsonl') {
  Get-Content 'rag/context_topk.jsonl' | ForEach-Object { $o = $_ | ConvertFrom-Json; if (-not (AddLine $o)) { return } }
} else {
  $arr = Get-Content 'context/_latest/TRIMMED.json' -Raw | ConvertFrom-Json
  foreach ($o in $arr) { if (-not (AddLine $o)) { break } }
}

$sel | ConvertTo-Json -Depth 5 | Out-File 'context/_latest/TRIMMED.json' -Encoding utf8
