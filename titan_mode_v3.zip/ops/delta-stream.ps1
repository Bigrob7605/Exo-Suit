param([string]$base="main")

$ErrorActionPreference='Stop'
git rev-parse --is-inside-work-tree 2>$null | Out-Null
$diff = git diff $base...HEAD --unified=0
New-Item -ItemType Directory -Force -Path 'context/_delta' | Out-Null
$path = 'context/_delta/DIFF.patch'
$diff | Out-File $path -Encoding utf8

@"
# Delta Context
Base: $base
File: DIFF.patch
Load this patch to see only the changed hunks. Apply specs/tests to these areas first.
"@ | Out-File 'context/_delta/README.md' -Encoding utf8
Write-Host "Delta emitted to $path"
