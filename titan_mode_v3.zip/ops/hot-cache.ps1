param([string]$q, [int]$ttlMinutes=120)

$ErrorActionPreference='Stop'
New-Item -ItemType Directory -Force -Path 'restore\hotcache' | Out-Null
$sha1 = New-Object -TypeName System.Security.Cryptography.SHA1Managed
$h = [System.BitConverter]::ToString($sha1.ComputeHash([Text.Encoding]::UTF8.GetBytes($q))).Replace('-','').ToLower()
$file = "restore\hotcache\$h.json"
if (Test-Path $file) {
  $age = (Get-Date) - (Get-Item $file).LastWriteTime
  if ($age.TotalMinutes -lt $ttlMinutes) {
    Write-Host "HotCache HIT: $q"
    Copy-Item $file 'context/_latest/TRIMMED.json' -Force
    exit 0
  }
}
Write-Host "HotCache MISS: $q"
python longbrain\retrieve.py --query "$q" --topk 60 --budget 128000 | Out-Null
Copy-Item 'context/_latest/TRIMMED.json' $file -Force
