param([string]$name = "ai-sbx-$([DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss'))")

$ErrorActionPreference='Stop'
Set-StrictMode -Latest

git rev-parse --is-inside-work-tree 2>$null | Out-Null
$root = (git rev-parse --show-toplevel).Trim()
$sand = Join-Path $root ".sandboxes\$name"
New-Item -ItemType Directory -Force $sand | Out-Null

git worktree add "$sand" -b $name
Write-Host "Sandbox ready: $sand"
Write-Host "Open this folder in Cursor, make changes, then run the finalize command below:"
Write-Host "  cd `"$sand`""
Write-Host "  git add -A"
Write-Host "  git commit -m `"AI sandbox patch`""
Write-Host "  cd `"$root`""
Write-Host "  git diff main...$name > restore\AI_PATCH.diff"
Write-Host "  git merge --no-ff --no-commit $name"
