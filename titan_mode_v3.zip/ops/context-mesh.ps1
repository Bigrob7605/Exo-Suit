param([int]$windowTokens=64000)

$ErrorActionPreference='Stop'
$t = Get-Content 'context/_latest/TRIMMED.json' -Raw | ConvertFrom-Json
if (-not $t) { Write-Error "No TRIMMED.json"; exit 1 }

New-Item -ItemType Directory -Force -Path 'context/_mesh' | Out-Null
$bucket=@(); $tok=0; $i=1
foreach ($o in $t) {
  $len = [math]::Ceiling(($o.text.Length)/4)
  if ($tok + $len -gt $windowTokens -and $bucket.Count -gt 0) {
    $bucket | ConvertTo-Json -Depth 5 | Out-File ("context/_mesh/window_$i.json") -Encoding utf8
    $i++; $bucket=@(); $tok=0
  }
  $bucket += $o; $tok += $len
}
if ($bucket.Count -gt 0) { $bucket | ConvertTo-Json -Depth 5 | Out-File ("context/_mesh/window_$i.json") -Encoding utf8 }

@"
# Context Mesh Index
Windows: $i

Load windows one by one:
$(Get-ChildItem context/_mesh/window_*.json | % { "- " + $_.Name } | Out-String)
"@ | Out-File 'context/_mesh/INDEX.md' -Encoding utf8
Write-Host "Built $i windows."
