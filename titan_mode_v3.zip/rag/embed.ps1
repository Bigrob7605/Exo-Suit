$ErrorActionPreference='Stop'

# write filelist to temp to avoid huge argv
$temp = Join-Path $env:TEMP "rag_files.txt"
Get-ChildItem -Recurse -File -Include *.py,*.js,*.ts,*.tsx,*.rs,*.go,*.cs,*.md,*.txt,*.yml,*.yaml `
  -Exclude node_modules,target,__pycache__,bin,obj,dist,build |
  % FullName | Out-File $temp -Encoding utf8

python "$PSScriptRoot\build_index.py" --filelist "$temp"
python "$PSScriptRoot\retrieve.py"    --query "bootstrap" --topk 1 2>$null | Out-Null
