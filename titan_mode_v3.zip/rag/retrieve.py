import sys, json, faiss, numpy as np, argparse
from sentence_transformers import SentenceTransformer
from util import read_env

p = argparse.ArgumentParser()
p.add_argument("--query", required=True)
p.add_argument("--topk", type=int, default=60)
args = p.parse_args()

cfg = read_env()
model = SentenceTransformer(cfg.get('EMBEDDING_MODEL','all-MiniLM-L6-v2'))
index = faiss.read_index(cfg.get('FAISS_INDEX_PATH','rag/index.faiss'))
meta  = [json.loads(x) for x in open(cfg.get('RAG_META_PATH','rag/meta.jsonl'), encoding='utf-8')]

qv = model.encode([args.query], normalize_embeddings=True, convert_to_numpy=True).astype('float32')
D,I = index.search(qv, args.topk)
out = []
for idx,score in zip(I[0].tolist(), D[0].tolist()):
    if idx < 0: continue
    m = meta[idx]
    with open(m["path"], encoding='utf-8', errors='ignore') as f:
        text = f.read()
    out.append({"path": m["path"], "chunk": m["chunk"], "score": float(score), "text": text})

with open('rag/context_topk.jsonl','w', encoding='utf-8') as f:
    for o in out: f.write(json.dumps(o, ensure_ascii=False)+'\n')

print(json.dumps({"count": len(out)}))
