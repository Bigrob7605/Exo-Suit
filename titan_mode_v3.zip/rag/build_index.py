import os, faiss, json, numpy as np, argparse, pathlib
from sentence_transformers import SentenceTransformer
from util import read_env, chunk_text

p = argparse.ArgumentParser()
p.add_argument("--filelist", required=True)
args = p.parse_args()

cfg = read_env()
model = SentenceTransformer(cfg.get('EMBEDDING_MODEL','all-MiniLM-L6-v2'))

paths = [line.strip() for line in open(args.filelist, encoding="utf-8") if line.strip()]
meta, texts = [], []
for pth in paths:
    try:
        txt = open(pth, encoding="utf-8", errors="ignore").read()
    except Exception:
        continue
    for i,chunk in enumerate(chunk_text(txt, int(cfg.get('CHUNK_TOKENS',800)), int(cfg.get('CHUNK_OVERLAP',120)) )):
        meta.append({"path": pth, "chunk": i})
        texts.append(chunk)

emb = model.encode(texts, normalize_embeddings=True, convert_to_numpy=True).astype('float32')
index = faiss.IndexFlatIP(emb.shape[1]); index.add(emb)

faiss.write_index(index, cfg.get('FAISS_INDEX_PATH','rag/index.faiss'))
with open(cfg.get('RAG_META_PATH','rag/meta.jsonl'), 'w', encoding='utf-8') as f:
    for m in meta: f.write(json.dumps(m, ensure_ascii=False)+'\n')

with open('rag/context.json','w', encoding='utf-8') as f:
    json.dump([{"path":m["path"],"chunk":m["chunk"],"score":1.0} for m in meta], f)
print(json.dumps({"chunks":len(texts),"files":len(paths)}))
