import os, re, json

def read_env(path=".env"):
    env = {}
    if os.path.exists(path):
        for line in open(path, encoding="utf-8"):
            if "=" in line:
                k,v = line.strip().split("=",1); env[k]=v
    return env

def tokenize_estimate(s:str)->int:
    return max(1, int(len(s)/4))

def chunk_text(text, tok=800, overlap=120):
    words = re.split(r'(\s+)', text)
    out, cur, cur_tok = [], [], 0
    for w in words:
        t = tokenize_estimate(w)
        if cur_tok + t > tok and cur:
            out.append(''.join(cur))
            keep = out[-1][-overlap*4:] if overlap else ''
            cur, cur_tok = [keep], tokenize_estimate(keep)
        cur.append(w); cur_tok += t
    if cur: out.append(''.join(cur))
    return out
