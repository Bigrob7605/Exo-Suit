param([switch]$skipTests)

$ErrorActionPreference = 'Stop'; Set-StrictMode -Latest

# Ultimate Performance
$guid = 'e9a42b02-d5df-448d-aa00-03f14749eb61' # Ultimate Performance
try { powercfg -duplicatescheme $guid | Out-Null } catch {}
powercfg -setactive $guid
powercfg -change -standby-timeout-ac 0
powercfg -change -hibernate-timeout-ac 0

# Scratch
$cacheDrive = (Get-Content .env | ? {$_ -match '^CACHE_DRIVE='}) -replace 'CACHE_DRIVE=',''
if ([string]::IsNullOrWhiteSpace($cacheDrive)) { $cacheDrive = 'C:' }
$cache = Join-Path $cacheDrive 'exocache'
New-Item -ItemType Directory -Force $cache | Out-Null
$env:TEMP=$cache; $env:TMP=$cache

# Build/context (assumes ops from prior exo-suit)
if (Test-Path .\ops\make-pack.ps1) {
  .\ops\make-pack.ps1   $PSScriptRoot "$PSScriptRoot\context\_latest"
}
if (Test-Path .\ops\index-symbols.ps1) { .\ops\index-symbols.ps1 }
if (Test-Path .\ops\index-imports.ps1) { .\ops\index-imports.ps1 }
if (Test-Path .\ops\placeholder-scan.ps1) { .\ops\placeholder-scan.ps1 }
if (Test-Path .\ops\drift-gate.ps1) { .\ops\drift-gate.ps1 -json }

# RAG (if present)
if (Test-Path .\rag\embed.ps1) { .\rag\embed.ps1 }

# Longbrain (build occasionally; retrieve per task)
if (-not (Test-Path "longbrain/index.faiss")) { python longbrain\build.py }

# GPU status
if (Test-Path .\ops\gpu-guardian.ps1) { .\ops\gpu-guardian.ps1 }

# Typical task: prefer HotCache → Longbrain → Mesh (seed with a neutral query)
$task = "bootstrap project context"
if (Test-Path .\ops\hot-cache.ps1) { .\ops\hot-cache.ps1 -q $task }
if (Test-Path .\ops\context-mesh.ps1) { .\ops\context-mesh.ps1 -windowTokens 64000 }

# Lint swarm
$lint = @(
  { if (Test-Path package.json) { npm run -s lint 2>$null } },
  { if (Get-Command ruff -EA SilentlyContinue) { ruff check . --fix } },
  { if (Test-Path Cargo.toml) { cargo clippy -q } },
  { if (Get-Command pyright -EA SilentlyContinue) { pyright } }
)
$jobs = $lint | % { Start-Job $_ }
$jobs | Receive-Job -Wait | Out-String | Write-Host

if (-not $skipTests) {
  $tests = @(
    { if (Test-Path package.json) { npm -s test } },
    { if (Get-ChildItem -Recurse -Filter "*_test.py" -EA SilentlyContinue) { pytest -q } },
    { if (Test-Path Cargo.toml) { cargo test --quiet } }
  )
  $tjobs = $tests | % { Start-Job $_ }
  $tjobs | Receive-Job -Wait | Out-String | Write-Host
}

# Diagrams
if (Test-Path .\mermaid\generate-maps.ps1) { .\mermaid\generate-maps.ps1 }

# Sentinel & Dashboard if present
if (Test-Path .\ops\sentinel-secrets.ps1) { .\ops\sentinel-secrets.ps1 }
if (Test-Path .\ops\sentinel-binaries.ps1) { .\ops\sentinel-binaries.ps1 -maxSizeMB 75 }
if (Test-Path .\ops\specmap-enforce.ps1) { .\ops\specmap-enforce.ps1 }
if (Test-Path .\ops\dashboard.ps1) { .\ops\dashboard.ps1 }

Write-Host "🔥 Titan‑Mode v3 armed. Load Cursor and follow COMMAND_QUEUE." -ForegroundColor Cyan
