$ErrorActionPreference='Stop'
try {
  if (Test-Path package.json) {
    npm ls --json | Out-File 'mermaid/dep.json'
    python mermaid/dep2mmd.py
  }
} catch { Write-Warning "Mermaid dep graph skipped: $_" }
