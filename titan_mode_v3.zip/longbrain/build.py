import os, json, faiss, numpy as np, argparse
from sentence_transformers import SentenceTransformer
from rank_bm25 import BM25Okapi
from util import read_env, iter_files, est_tokens, hash_text

p = argparse.ArgumentParser()
p.add_argument("--roots", nargs="+", default=["."])
p.add_argument("--chunk", type=int, default=800)
p.add_argument("--overlap", type=int, default=120)
p.add_argument("--ext", nargs="+", default=[".py",".js",".ts",".tsx",".rs",".go",".cs",".md",".txt",".yml",".yaml"])
p.add_argument("--exclude", nargs="+", default=[".git","node_modules","dist","build","target","__pycache__","context","rag","restore"])
a = p.parse_args()

cfg = read_env()
model = SentenceTransformer(cfg.get('EMBEDDING_MODEL','all-MiniLM-L6-v2'))

docs, toks, meta = [], [], []
for path in iter_files(a.roots, set(a.ext), set(a.exclude)):
    try:
        text = open(path, encoding="utf-8", errors="ignore").read()
    except:
        continue
    i=0; pos=0
    while pos < len(text):
        end = min(len(text), pos + a.chunk*4)
        chunk = text[pos:end]
        docs.append(chunk)
        toks.append(est_tokens(chunk))
        meta.append({"path":path, "chunk":i})
        pos = max(end - a.overlap*4, end)
        i += 1

emb = model.encode(docs, normalize_embeddings=True, convert_to_numpy=True).astype('float32')
index = faiss.IndexFlatIP(emb.shape[1]); index.add(emb)
faiss.write_index(index, "longbrain/index.faiss")

with open("longbrain/meta.jsonl","w",encoding="utf-8") as f:
    for m in meta: f.write(json.dumps(m, ensure_ascii=False)+"\n")

tokenized = [d.split() for d in docs]
bm25 = BM25Okapi(tokenized)
with open("longbrain/bm25.json","w",encoding="utf-8") as f:
    json.dump({"docsN":len(docs)}, f)

print(json.dumps({"chunks":len(docs)}))
