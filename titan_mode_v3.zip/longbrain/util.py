import os, re, json, hashlib

def read_env(path=".env"):
    env = {}
    if os.path.exists(path):
        for line in open(path, encoding="utf-8"):
            if "=" in line:
                k,v = line.strip().split("=",1); env[k]=v
    return env

def est_tokens(s:str)->int:
    return max(1, len(s)//4)

def iter_files(roots, include_ext, exclude_dirs):
    for root in roots:
        for dp, dn, fn in os.walk(root):
            if any(x.lower() in dp.lower() for x in exclude_dirs):
                continue
            for f in fn:
                ext = os.path.splitext(f)[1].lower()
                if ext in include_ext:
                    yield os.path.join(dp,f)

def hash_text(s:str)->str:
    return hashlib.sha1(s.encode('utf-8','ignore')).hexdigest()
