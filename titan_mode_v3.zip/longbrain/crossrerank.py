from sentence_transformers import CrossEncoder
import numpy as np, json, argparse

p = argparse.ArgumentParser()
p.add_argument("--query", required=True)
p.add_argument("--docsPath", required=True)
p.add_argument("--topk", type=int, default=40)
args = p.parse_args()

model = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
pairs, metas = [], []
with open(args.docsPath, encoding='utf-8') as f:
    for line in f:
        o = json.loads(line)
        pairs.append((args.query, o["text"]))
        metas.append(o)

scores = model.predict(pairs)
order = np.argsort(-scores)[:args.topk]
out = []
for i in order:
    m = metas[i]
    m["xscore"] = float(scores[i])
    out.append(m)
print(json.dumps(out, ensure_ascii=False))
