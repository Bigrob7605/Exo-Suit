import os, json, faiss, numpy as np, argparse, subprocess, sys
from sentence_transformers import SentenceTransformer
from util import read_env, est_tokens

p = argparse.ArgumentParser()
p.add_argument("--query", required=True)
p.add_argument("--bm25k", type=int, default=200)
p.add_argument("--faissk", type=int, default=120)
p.add_argument("--topk", type=int, default=60)
p.add_argument("--budget", type=int, default=128000)
a = p.parse_args()

cfg = read_env()
index = faiss.read_index("longbrain/index.faiss")
meta  = [json.loads(x) for x in open("longbrain/meta.jsonl", encoding="utf-8")]
docsN = len(meta)

def get_text(m):
    with open(m["path"], encoding='utf-8', errors='ignore') as f:
        return f.read()

# Stage 1: BM25 placeholder (not persisted for simplicity)
bm25_idxs = list(range(min(a.bm25k, docsN)))

# Stage 2: FAISS
model = SentenceTransformer(cfg.get('EMBEDDING_MODEL','all-MiniLM-L6-v2'))
qv = model.encode([a.query], normalize_embeddings=True, convert_to_numpy=True).astype('float32')
D,I = index.search(qv, a.faissk)
cand = set(bm25_idxs + I[0].tolist())

tmpPath = "longbrain/candidates.jsonl"
with open(tmpPath,'w',encoding='utf-8') as out:
    for idx in cand:
        if idx < 0 or idx >= docsN: continue
        m = meta[idx]
        txt = get_text(m)
        out.write(json.dumps({"text":txt, "meta":m, "score":float(0.0)})+"\n")

r = subprocess.run([sys.executable,"longbrain/crossrerank.py","--query",a.query,"--docsPath",tmpPath,"--topk",str(a.topk)],
                   capture_output=True, text=True)
top = json.loads(r.stdout)

budget = a.budget
sel=[]
for o in top:
    t = est_tokens(o["text"])
    if t <= budget:
        sel.append(o); budget -= t
    else: break

with open("context/_latest/TRIMMED.json","w",encoding='utf-8') as f:
    json.dump(sel, f, ensure_ascii=False, indent=2)

print(json.dumps({"selected":len(sel),"budget_left":budget}))
